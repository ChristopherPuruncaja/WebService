package com.example.webservice;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    EditText tvnombre, tvemail, tvcontacto,tvdireccion;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       tvnombre = findViewById(R.id.tvnombre);
       tvemail= findViewById(R.id.tvemail);
        tvcontacto= findViewById(R.id.tvcontacto);
        tvdireccion=findViewById(R.id.tvdireccion);

        btn1=findViewById(R.id.btninsertar);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertar ();
            }
        });


    }

    private void insertar() {
        String nombre = tvnombre.getText().toString().trim();
        String email = tvemail.getText().toString().trim();
        String contacto = tvcontacto.getText().toString().trim();
        String direccion = tvdireccion.getText().toString().trim();

        ProgressDialog progressDialog = new ProgressDialog(this);
        if (nombre.isEmpty()) {
            tvnombre.setError("Complete los campos");
        } else if (email.isEmpty()) {
            tvemail.setError("Complete los campos");
        } else if (contacto.isEmpty()) {
            tvcontacto.setError("Complete los campos");
        } else if (direccion.isEmpty()) {
            tvdireccion.setError("Complete los campos");
        } else {
            progressDialog.show();
            StringRequest request = new StringRequest(Request.Method.POST, "https://aeropuertomariscallamar.000webhostapp.com/crud/insert.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            if (response.equalsIgnoreCase("Datos insertados")) {

                                Toast.makeText(MainActivity.this, "Datos insertados", Toast.LENGTH_SHORT).show();

                                progressDialog.dismiss();
                            } else {
                                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String, String> params = new HashMap<String, String>();

                    params.put("nombre", nombre);
                    params.put("email", email);
                    params.put("contacto", contacto);
                    params.put("direccion", direccion);


                    return params;
                }
            };


            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(request);


        }
    }
}